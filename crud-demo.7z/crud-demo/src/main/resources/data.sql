insert into student
values(101,'Sangetha', 'Physics');

insert into student
values(102,'Sharath', 'Commerce');

insert into student 
values (103, 'John' , 'B.Maths');