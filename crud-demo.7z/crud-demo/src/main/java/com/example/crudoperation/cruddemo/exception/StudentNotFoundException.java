package com.example.crudoperation.cruddemo.exception;

@SuppressWarnings("serial")
public class StudentNotFoundException extends RuntimeException {
	
 public StudentNotFoundException (String ex) {
	 super (ex);
 }
}
