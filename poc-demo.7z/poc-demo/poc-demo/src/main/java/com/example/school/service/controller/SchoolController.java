package com.example.school.service.controller;

public class SchoolController {

}
