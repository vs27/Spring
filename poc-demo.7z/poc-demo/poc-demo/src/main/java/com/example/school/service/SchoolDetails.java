package com.example.school.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolDetails {

	public static void main(String[] args) {
		SpringApplication.run(SchoolDetails.class, args);
	}

}

